require 'rails_helper'

RSpec.describe Comment, type: :model do

  let(:topic) do
    create(:topic)
  end

  let(:post_sample) do
    create(:post, topic_id: topic.id )
  end

  subject { build(:comment, post_id: post_sample.id)}

  it "is valid with valid attributes" do
    expect(subject.save).to eq(true)
  end

  it "is valid with comment" do
    expect(subject).to be_valid
  end

  it "is not valid without a description" do
    subject.description = nil
    expect(subject).to_not be_valid
  end

  describe 'association belongs to user' do
    it { should belong_to(:user)}
  end

  describe 'association should respond to user' do
    it { should respond_to(:user_id)}
  end
end
