require 'rails_helper'

RSpec.describe Rating, type: :model do

  let(:topic) do
    create(:topic)
  end

  let(:post_sample) do
    create(:post, topic_id: topic.id )
  end

  subject { build(:rating, post_id: post_sample.id)}

  it "is valid with ratings" do
    expect(subject).to be_valid
  end

  describe 'association has and belong to' do
    it { should belong_to(:post)}
  end
end
