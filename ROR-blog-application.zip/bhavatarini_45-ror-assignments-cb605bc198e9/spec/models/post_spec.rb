require 'rails_helper'

RSpec.describe Post, type: :model do

  let(:topic) do
    create(:topic)
  end

  subject { build(:post, topic_id: topic.id)}

  it "is valid with valid attributes" do
    expect(subject).to be_valid
  end

  it "is not valid without a title" do
    subject.title = nil
    expect(subject).to_not be_valid
  end

  it "is not valid without a body" do
    subject.title = nil
    subject.body = nil
    expect(subject).to_not be_valid
  end

  describe 'association has one attached to' do
    it { should have_one_attached(:image)}
  end

  describe 'association belongs to user' do
    it { should belong_to(:user)}
  end

  describe 'association should respond to user' do
    it { should respond_to(:user_id)}
  end
end
