require 'rails_helper'

RSpec.describe Tag, type: :model do

  subject{ build(:tag)}

  it 'is valid with valid attributes' do
    expect(subject.save).to eq(true)
  end

  it 'is not valid without name' do
    expect(subject).to be_valid
  end

  it 'is not valid without name' do
    subject.name = nil
    expect(subject).to_not be_valid
  end

  describe 'Associations' do
    it { should have_and_belong_to_many(:posts)}
  end
end
