require 'rails_helper'

RSpec.describe "Ratings", type: :request do

  before do
    @user = user
    sign_in @user
  end

  let(:topic) do
    create(:topic)
  end

  let(:post_sample) do
    create(:post, topic_id: topic.id, user_id: user.id)
  end

  let(:rating_sample) do
    create(:rating, post_id: post_sample.id)
  end

  let(:user) do
    create(:user)
  end

  describe "GET /create" do
    it "returns http success" do
      expect { post topic_post_ratings_path(topic, post_sample), params: {rating: { ratings: "5"}}}.to change(Rating, :count).by(1)
    end

    it "returns http success" do
      post topic_post_ratings_path(topic, post_sample), params: {rating: {ratings: "1"}}
      expect(response).to have_http_status(302)
    end

    it "redirects to created ratings" do
      post topic_post_ratings_path(topic, post_sample), params: {rating: {ratings: "1"}}
      expect(response).to redirect_to topic_post_url(topic, post_sample)
    end
  end
end
