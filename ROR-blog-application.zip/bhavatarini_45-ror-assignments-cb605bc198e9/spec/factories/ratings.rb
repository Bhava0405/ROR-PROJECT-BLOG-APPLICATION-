FactoryBot.define do
  factory :rating do
    ratings { 1 }
  end
end
