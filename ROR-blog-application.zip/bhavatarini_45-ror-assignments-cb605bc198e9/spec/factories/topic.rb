
FactoryBot.define do
  factory :topic do
    name {"sports"}
  end
end
