FactoryBot.define do
  factory :tag do
    name { "MyString" }
  end
end
