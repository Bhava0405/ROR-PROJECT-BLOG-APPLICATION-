FactoryBot.define do
  factory :post do
    title {"cricket"}
    body {"It is a national sport"}
    association :user
  end
end
