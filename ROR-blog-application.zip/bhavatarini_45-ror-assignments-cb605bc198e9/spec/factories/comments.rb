FactoryBot.define do
  factory :comment do
    description { "MyString" }
    association :user
  end
end
