class AddRefToComments < ActiveRecord::Migration[7.0]
  def change
    add_reference :comments, :post, null: false
  end
end
