class AddRefToRatings < ActiveRecord::Migration[7.0]
  def change
    add_reference :ratings, :post, null: false
  end
end
