Rails.application.routes.draw do
  devise_for :users
  resources :tags
  root "topics#index"
  resources :posts, only: :index
  resources :topics do
    resources :posts do
      resources :comments
      resources :ratings, only: :create
    end
  end

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
