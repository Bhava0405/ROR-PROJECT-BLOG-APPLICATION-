class Post < ApplicationRecord
  belongs_to :topic
  belongs_to :user
  has_many :comments , dependent: :destroy
  has_many :ratings, dependent: :destroy
  has_and_belongs_to_many :tags
  accepts_nested_attributes_for :tags, reject_if: proc{|attributes| attributes['name'].blank?}
  validates :title, presence: true
  validates :body, presence: true
  has_one_attached :image
end
