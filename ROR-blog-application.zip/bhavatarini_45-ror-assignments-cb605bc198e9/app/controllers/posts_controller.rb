class PostsController < ApplicationController
  before_action :set_topic, only: %i[ show edit update destroy new create]
  before_action :set_post, only: %i[ show edit update destroy ]
  load_and_authorize_resource
  # GET /posts or /posts.json
  def index
    if params[:topic_id]
      @topic = Topic.find(params[:topic_id])
      @posts = @topic.posts.all
    else
      @posts = Post.includes(:topic, :user)
    end
    @posts = @posts.paginate(page: params[:page], per_page: 10)
  end
  # GET /posts/1 or /posts/1.json
  def show
    @rating = @post.ratings.new
    @current_ratings = @post.ratings.group(:ratings).count
    @average_ratings = @post.ratings.average(:ratings)
  end

  # GET /posts/new
  def new
    @post = @topic.posts.new
  end

  # GET /posts/1/edit
  def edit
  end

  # POST /posts or /posts.json
  def create
    @post = @topic.posts.new(post_params.merge(user_id: current_user.id))

    respond_to do |format|
      if @post.save
        format.html { redirect_to topic_posts_url(@topic), success: "Post was created successfully." }
        format.json { render :show, status: :created, location: @post }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @post.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /posts/1 or /posts/1.json
  def update

    respond_to do |format|
      if @post.update(post_params)
        format.html { redirect_to topic_posts_url(@topic, @post), success: "Post was updated successfully." }
        format.json { render :show, status: :ok, location: @post }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @post.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /posts/1 or /posts/1.json
  def destroy
    @post.destroy

    respond_to do |format|
      format.html { redirect_to topic_posts_url(@post.topic_id), success: "Post was successfully destroyed."  }
      format.json { head :no_content }
    end
  end

  private

    def set_topic
      @topic = Topic.find(params[:topic_id])
    end

    # Use callbacks to share common setup or constraints between actions.
    def set_post
      @post = @topic.posts.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def post_params
      params.require(:post).permit(:title, :body, :image, tag_ids:[], tags_attributes: [:name])
    end
end
