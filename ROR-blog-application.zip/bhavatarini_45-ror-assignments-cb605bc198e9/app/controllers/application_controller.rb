class ApplicationController < ActionController::Base
  before_action :authenticate_user!
  before_action :configure_permitted_parameters, if: :devise_controller?

  rescue_from CanCan::AccessDenied do |exception|
    redirect_to topic_posts_url(@topic), alert: exception.message
  end

  add_flash_types :danger, :info, :success, :error
  include ActiveStorage::SetCurrent

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:first_name, :last_name, :phone, :address, :username])
  end
end
