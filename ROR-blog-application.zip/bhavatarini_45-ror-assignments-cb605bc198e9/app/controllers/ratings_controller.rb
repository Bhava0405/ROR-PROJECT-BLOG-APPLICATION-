class RatingsController < ApplicationController
  before_action :set_topic
  before_action :set_post

  def create
    @rating = @post.ratings.new(rating_params)

    respond_to do |format|
      if @rating.save
        format.html { redirect_to topic_post_url(@topic, @post) }
      else
        format.html { render :new, status: :unprocessable_entity }
      end
    end
  end

  private

  def set_topic
    @topic = Topic.find(params[:topic_id])
  end

  def set_post
    @post = @topic.posts.find(params[:post_id])
  end

  # Only allow a list of trusted parameters through.
  def rating_params
    params.require(:rating).permit(:ratings)
  end

end
